<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">

</head>

<body>
    <section class="header">

        <a href="home.php" class="logo">Travel</a>
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="about.php">about</a>
            <a href="packages.php">packages</a>
            <a href="book.php">book</a>
            <a href="feedback.php">feedback</a>
        </nav>
        <div id="menu-btn" class="fas fa-bars"></div>
    </section>

    <div class="heading" style="background: url(img/1000.jpg) no-repeat">
        <h1>About us</h1>
        
    </div>
    <section class="about">
        <div class="image">
            <img src="img/About-us1.jpg" alt="">
        </div>
        <div class="content">
            <h3>Why choose us?</h3> <br>
            <h2>More Than 20 Years Of Experience, Variety Of Tour Packages, Best Deals And Personalised 
                Services.</h2>  <br>
        <div class="box-container">
           

                <div class="box">
                    <h3>experience</h3>
            <p>
                Our dedicated travel team diligently works round-the-clock to design the best travel experiences 
                for the customers. The skilled team spends considerable amounts of time ideating tour packages that guarantee to 
                make travelling with us an experience like no other. We select the finest hotels in every category, 
                boast an excellent personal fleet of vehicles for transportation. </p>
            </div>
            <div class="box">
                <h3> Positive Customer Feedback</h3> 
               <p> We're truly humbled to have received volumes of positive customer 
                feedback for our services. This appreciation from our prestigious 
                clients is more valuable than any award for us. As a customer-driven 
                travel company, our priority has always been their satisfaction. Therefore, 
                our dedicated team of experts endeavours to achieve the goal of making our 
                customers happy. </p>
            </div>
            <div class="box">
                <h3> Recognition </h3> 
               <p> We are proud to be accredited by major tour and travel associations in India and world like IATA, IATO, TAAI, IMF, MOT (Ministry of Tourism, Govt of India), and TOFT. It is an honour for us to 
                be able to be a part of crucial initiatives towards safeguarding animal 
                rights, protection of endangered species, and responsible</p>
            </div>
            </div>
                    <div class="icons-container">
                        <div class="icons">
                            <i class="fas fa-map"></i>
                            <span>Top destinations</span>
                        </div>
                       
                    <div class="icons">
                        <i class="fas fa-hand-holding-usd"></i>
                        <span>affordable price</span>
                    </div>
                    <div class="icons">
                        <i class="fas fa-headset"></i>
                        <span>24/7 Guide service</span>
                    </div>
                </div> 
        </div> 

    </section>

    <section class="reviews">
        <div class="heading-title">
            <h3>Clients Reviews</h3>
        </div>
        <div class=" swiper reviews-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia consequuntur consequatur 
                        tenetur? Mollitia nemo quae maxime fuga necessitatibus? Iure, quae.</p>
                        <h3>virat kohli</h3>
                        <span> Tourist </span>
                        <img src="img/virat.jpg" alt="">
                </div>
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Neque, aperiam incid
                        unt suscipit cupiditate labore pariatur ad at magni blanditiis commodi! Eos 
                        minima nemo sequi quas maxime distinctio fugit delectus adipisci.
                    </p>
                        <h3>Rohit sharma</h3>
                        <span> Tourist </span>
                        <img src="img/3.jpg" alt="">
                </div>
                <div class="swiper-slide slide">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse dignissimos, 
                        dolorem maxime fuga nisi natus tempora laboriosam dolorum reprehenderit
                         perferendis ullam eaque. 
                        Saepe, commodi voluptates!
                    </p>
                        <h3>Ms Dhoni</h3>
                        <span> Tourist </span>
                        <img src="img/msdhoni.jpg" alt="">

            </div>
            <div class="swiper-slide slide">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse dignissimos, 
                    dolorem maxime fuga nisi natus tempora laboriosam doloru
                </p>
                    <h3>Dinesh karthik</h3>
                    <span> Tourist </span>
                    <img src="img/Dk.jpg" alt="">
        </div>
        <div class=" swiper-slide slide">
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse dignissimos, 
                dolorem maxime fuga nisi natus tempora laboriosam doloru abcd efgh ijkl mnop 
                qtsr uvw  xyz
            </p>
                <h3>K L Rahul</h3>
                <span> Tourist </span>
                <img src="img/Kl.jpg" alt="">
                </div>
                </div>
                </div>
    </section>
  


























    <section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="#"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="#"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="#"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="#"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 9730906583 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 8855936955</a>
         <a href="#"> <i class="fas fa-envelope"></i> Sheth_Family </a>
         <a href="#"> <i class="fas fa-map"></i> Sai Nagar,Amravati 444607 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Sheth_Family</span> &#169 all rights reserved! </div>
   
</section>


    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>


    <script src="js/script.js"></script>
</body>

</html>
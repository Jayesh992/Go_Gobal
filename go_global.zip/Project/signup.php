<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    <div class="container">
        <div class="forms-container">
            <div class="signin-signup">
                <form action="home.php" class="sign-in-form">
                    <h2 class="title">Sign in</h2>
                    <div class="input-feild">
                        <i class="fas fa-user"></i>
                        <input type="text"  name = "name" placeholder="username">
                    </div>
                    <div class="input-feild">
                        <i class="fas fa-lock"></i>
                        <input type="password" name = "password" placeholder="password">
                    </div>
                  <a href="home.php"> <input type="Submit" value='Login'  class="btn solid"  name="login"></a> 
                    <p class=social-text>or sign in wih social platforms</p>
                    <div class="social-media">
                        <a href="#" class="social-icon">
                            <i class="fab fa-facebook-f"></i> 
                        </a>
                        <a href="#" class="social-icon">
                            <i class="fab fa-twitter"></i>
                            </a>
                     <a href="#" class="social-icon">
                        <i class="fab fa-instagram"></i>
                           </a>
                      <a href="#" class="social-icon">
                        <i class="fab fa-linkedin"></i>
                        </a>

                    </div>

                </form>
                </div>
                </div>
                </div>


                </body>

</html>